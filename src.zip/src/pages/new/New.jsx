import "./new.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";

const New = ({title}) => {

return (
  <div className="new">
    <Sidebar />
    <div className="newContainer">
      <Navbar />
      <div className="top">
        <h1>{title}</h1>
      </div>
      <div className="bottom">
        <div className="left">
          <img
          src =""
          alt=""
          />
        </div>
        <div className="right">
          <form>
            <div className="formInput">
              <label htmlFor="file">
                image: <DriveFolderUploadOutlinedIcon className="icon" />
              </label>
              <input type="file" id="file" style={{display: "none"}} />
< input type = " file " id = " file " style = { { display : " none " } } />
</div >
<div className= "formInput">
<label>Rol</label>
<input type=" text " placeholder = "Admistrador" />
</div>
<div className = "formInput">
<label>Nombre</label>
<input type = " text " placeholder = "Nombre completo" />
</div>
<div className = " formInput " >
<label >Correo Electronico</label>
<input type = " email " placeholder = " admin@gmail.com " />
</div >
<div className = " formInput " >
<label >Telefono</label>
<input type = " text " placeholder = "12345678" />
</div>
<div className = " formInput " >
  <label>Contraseña</label>
  < input type="password" placeholder = "********"/>
</div >
< button >Send </button>
</form >
          </div>
      </div>
    </div>
  </div>
);
};

export default New;
